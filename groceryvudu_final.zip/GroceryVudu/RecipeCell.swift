//
//  RecipeCell.swift
//  GroceryVudu
//
//  Created by Cade on 10/2/14.
//  Copyright (c) 2014 Cade Ward. All rights reserved.
//

import Foundation
import UIKit

class RecipeCell: UITableViewCell {
    
    @IBOutlet weak var lblRecipeName: UILabel!
    @IBOutlet weak var lblTotalTime: UILabel!
    @IBOutlet weak var lblCategory: UILabel!

}